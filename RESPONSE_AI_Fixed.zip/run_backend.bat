@echo off
cd /d %~dp0
python -m venv .venv
call .venv\Scripts\activate
python -m pip install -r backend\requirements.txt
python -m uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
