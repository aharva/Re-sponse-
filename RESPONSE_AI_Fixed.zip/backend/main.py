import os, re, sqlite3, smtplib, ssl, time, threading
from collections import Counter
from datetime import datetime, timezone
from email.message import EmailMessage
from math import ceil
from pathlib import Path
from typing import Optional

import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parents[1]
CSV = ROOT / "data" / "reviews.csv"
DB = ROOT / "backend" / "response_ai.db"
load_dotenv(ROOT / ".env", override=True)

app = FastAPI(title="RE:SPONSE AI API", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
                   allow_methods=["*"], allow_headers=["*"])

# ---- notebook logic (cleaning, stopwords, critical = Rating <= 2) -------------------------
STOP = {"the","and","was","this","that","for","with","have","had","but","not","are","were","very","from","they","you","your","just","too","has","its","it","in","of","to","a","an","is","on","my","i","me","so","be","as","at","or","do","would","could","did","we","our","all","been","will","can","get","got","more","one","out","up","about","also","there","their"}
def clean_text(t):
    t = re.sub(r"[^a-zA-Z\s]", "", str(t).lower())
    return re.sub(r"\s+", " ", t).strip()
def words(t): return [w for w in clean_text(t).split() if w not in STOP and len(w) > 2]

CATS = {
 "Fit & sizing": {"size","fit","fits","small","large","tight","big","short","long","snug","loose","petite","length","sizing","bigger","smaller","tts"},
 "Fabric & material": {"fabric","material","thin","scratchy","itchy","cheap","sheer","stiff","polyester","texture","feels","soft","rough","clingy"},
 "Quality & durability": {"quality","seams","ripped","tear","hole","stitching","button","zipper","shrunk","wash","washed","pilled","unraveled","fell","poorly","construction"},
 "Appearance & color": {"color","colour","picture","photo","online","pattern","print","looks","design","unflattering","ugly","different"},
}
def categorize(text):
    c = Counter(words(text)); best, score = "General", 0
    for cat, ws in CATS.items():
        s = sum(n for w, n in c.items() if w in ws)
        if s > score: best, score = cat, s
    return best

def severity(rating, rec):
    return "High" if rating == 1 or (rating == 2 and rec == 0) else "Medium" if rating == 2 else "Low"

def keywords_of(text, n=5):
    allc = {w for ws in CATS.values() for w in ws}
    c = Counter(words(text))
    return [w for w, _ in sorted(c.items(), key=lambda x: (x[0] not in allc, -x[1]))[:n]]

# ---- database -----------------------------------------------------------------------------
def now(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def db():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; return con

SCHEMA = """
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, clothing_id INT, age INT, title TEXT, review_text TEXT,
 rating INT, recommended INT, positive_feedback INT, division TEXT, department TEXT, class_name TEXT, is_critical INT, category TEXT);
CREATE TABLE IF NOT EXISTS ai_analyses(id INTEGER PRIMARY KEY AUTOINCREMENT, review_id INT, severity TEXT, category TEXT, keywords TEXT, summary TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS responses(id INTEGER PRIMARY KEY AUTOINCREMENT, review_id INT, subject TEXT, body TEXT, recipient TEXT, status TEXT,
 error TEXT, model TEXT, created_at TEXT, updated_at TEXT, approved_at TEXT, sent_at TEXT);
CREATE TABLE IF NOT EXISTS email_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, response_id INT, to_addr TEXT, test_mode INT, success INT, error TEXT, created_at TEXT);
"""
KW_CACHE = {}

@app.on_event("startup")
def startup():
    con = db(); con.executescript(SCHEMA)
    con.execute("UPDATE responses SET status='Failed',error='Send was interrupted. Retry sending.' WHERE status='Sending'"); con.commit()
    if con.execute("SELECT COUNT(*) FROM reviews").fetchone()[0] == 0:
        df = pd.read_csv(CSV)
        df = df.rename(columns={"Unnamed: 0": "id", "Clothing ID": "clothing_id", "Age": "age", "Title": "title", "Review Text": "review_text",
            "Rating": "rating", "Recommended IND": "recommended", "Positive Feedback Count": "positive_feedback",
            "Division Name": "division", "Department Name": "department", "Class Name": "class_name"})
        df["is_critical"] = ((df.rating <= 2) & df.review_text.notna()).astype(int)   # notebook: Rating<=2, drop null text
        df["category"] = [categorize(t) if isinstance(t, str) else "General" for t in df.review_text]
        cols = ["id","clothing_id","age","title","review_text","rating","recommended","positive_feedback","division","department","class_name","is_critical","category"]
        rows = df[cols].astype(object).where(df[cols].notna(), None).values.tolist()
        con.executemany(f"INSERT INTO reviews VALUES({','.join('?'*len(cols))})", rows); con.commit()
    c = Counter()
    for (t,) in con.execute("SELECT review_text FROM reviews WHERE is_critical=1"): c.update(words(t))
    KW_CACHE["kw"] = c; con.close()

def rv(r):
    d = dict(r); d["ref"] = f"RV-{d['id']:05d}"
    d["severity"] = severity(d["rating"], d["recommended"]); d["keywords"] = keywords_of(d["review_text"] or "")
    d["complaint_category"] = d["category"]; return d

def get_review(con, rid):
    r = con.execute("SELECT * FROM reviews WHERE id=?", (rid,)).fetchone()
    if not r: raise HTTPException(404, "Review not found")
    return rv(r)

def where(q=None, rating=None, critical=False, department=None, category=None, class_name=None):
    w, p = ["1=1"], []
    if critical: w.append("is_critical=1")
    if rating: w.append("rating=?"); p.append(rating)
    if department: w.append("department=?"); p.append(department)
    if class_name: w.append("class_name=?"); p.append(class_name)
    if category: w.append("category=?"); p.append(category)
    if q: w.append("(review_text LIKE ? OR title LIKE ? OR class_name LIKE ?)"); p += [f"%{q}%"] * 3
    return " AND ".join(w), p

def page_of(con, table, wh, p, page, size, order, mapper):
    total = con.execute(f"SELECT COUNT(*) FROM {table} WHERE {wh}", p).fetchone()[0]
    rows = con.execute(f"SELECT * FROM {table} WHERE {wh} ORDER BY {order} LIMIT ? OFFSET ?", p + [size, (page - 1) * size]).fetchall()
    return {"items": [mapper(r) for r in rows], "total": total, "page": page, "pages": max(1, ceil(total / size))}

# ---- analytics / reviews / products -------------------------------------------------------
@app.get("/api/health")
def health(): return {"status": "ok", "csv_found": CSV.exists()}

@app.get("/api/analytics")
def analytics():
    con = db(); q = lambda s, p=(): con.execute(s, p).fetchall()
    total = q("SELECT COUNT(*) FROM reviews")[0][0]; crit = q("SELECT COUNT(*) FROM reviews WHERE is_critical=1")[0][0]
    dist = {str(r[0]): r[1] for r in q("SELECT rating,COUNT(*) FROM reviews GROUP BY rating ORDER BY rating")}
    rec = q("SELECT AVG(recommended)*100 FROM reviews")[0][0]
    cats = [dict(r) for r in q("SELECT category name,COUNT(*) count FROM reviews WHERE is_critical=1 GROUP BY category ORDER BY count DESC")]
    def grp(col): return [dict(r) for r in q(f"SELECT {col} name,COUNT(*) reviews,SUM(is_critical) critical,ROUND(100.0*SUM(is_critical)/COUNT(*),2) critical_rate,ROUND(AVG(rating),2) avg_rating FROM reviews WHERE {col} IS NOT NULL GROUP BY {col} HAVING COUNT(*)>=50 ORDER BY critical_rate DESC")]
    resp = {r[0]: r[1] for r in q("SELECT status,COUNT(*) FROM responses GROUP BY status")}
    out = {"total_reviews": total, "critical_reviews": crit, "critical_percentage": round(crit / total * 100, 2),
        "average_rating": round(q("SELECT AVG(rating) FROM reviews")[0][0], 2), "recommendation_rate": round(rec, 1),
        "rating_distribution": dist, "critical_by_rating": {str(r[0]): r[1] for r in q("SELECT rating,COUNT(*) FROM reviews WHERE is_critical=1 GROUP BY rating")},
        "complaint_categories": cats, "problem_departments": grp("department"), "problem_classes": grp("class_name"),
        "recent_critical": [rv(r) for r in q("SELECT * FROM reviews WHERE is_critical=1 ORDER BY id DESC LIMIT 5")],
        "response_activity": {"total": sum(resp.values()), "by_status": resp, "emails_sent": resp.get("Sent", 0)}}
    con.close(); return out

@app.get("/api/keywords")
def keywords(limit: int = 15): return [{"word": w, "count": n} for w, n in KW_CACHE["kw"].most_common(limit)]

@app.get("/api/reviews")
def reviews(q: Optional[str] = None, rating: Optional[int] = None, critical: bool = False, department: Optional[str] = None,
            category: Optional[str] = None, page: int = 1, size: int = 20):
    con = db(); wh, p = where(q, rating, critical, department, category)
    r = page_of(con, "reviews", wh, p, page, size, "id DESC", rv)
    r["departments"] = [x[0] for x in con.execute("SELECT DISTINCT department FROM reviews WHERE department IS NOT NULL ORDER BY 1")]
    r["categories"] = list(CATS) + ["General"]; con.close(); return r

@app.get("/api/reviews/critical")
def critical_reviews(q: Optional[str] = None, page: int = 1, size: int = 20): return reviews(q=q, critical=True, page=page, size=size)

@app.get("/api/reviews/{rid}")
def review(rid: int):
    con = db(); r = get_review(con, rid)
    a = con.execute("SELECT * FROM ai_analyses WHERE review_id=? ORDER BY id DESC LIMIT 1", (rid,)).fetchone()
    r["saved_analysis"] = dict(a) if a else None; con.close(); return r

@app.get("/api/products")
def products():
    con = db()
    cls = [dict(r) for r in con.execute("SELECT department,class_name name,COUNT(*) reviews,ROUND(AVG(rating),2) avg_rating,SUM(is_critical) critical,ROUND(100.0*SUM(is_critical)/COUNT(*),2) critical_rate,ROUND(AVG(recommended)*100,1) recommend_rate FROM reviews WHERE class_name IS NOT NULL GROUP BY class_name ORDER BY reviews DESC")]
    items = [dict(r) for r in con.execute("SELECT clothing_id,class_name,COUNT(*) reviews,SUM(is_critical) critical,ROUND(AVG(rating),2) avg_rating FROM reviews GROUP BY clothing_id HAVING COUNT(*)>=20 ORDER BY SUM(is_critical)*1.0/COUNT(*) DESC LIMIT 10")]
    con.close(); return {"classes": cls, "most_problematic_items": items}

# ---- AI analysis + Gemini -----------------------------------------------------------------
class AnalyzeReq(BaseModel): review_id: int

@app.post("/api/analyze-review")
def analyze_review(req: AnalyzeReq):
    con = db(); r = get_review(con, req.review_id)
    summ = f"{r['severity']} severity {r['complaint_category'].lower()} complaint (rating {r['rating']}/5). Key terms: {', '.join(r['keywords']) or 'none'}."
    con.execute("INSERT INTO ai_analyses(review_id,severity,category,keywords,summary,created_at) VALUES(?,?,?,?,?,?)",
                (r["id"], r["severity"], r["complaint_category"], ",".join(r["keywords"]), summ, now())); con.commit(); con.close()
    return {"review_id": r["id"], "severity": r["severity"], "category": r["complaint_category"], "keywords": r["keywords"], "summary": summ}

def prompt_for(r):
    return f"""You are a professional customer support agent for an e-commerce clothing company.

A customer submitted this review:
Rating: {r['rating']}/5
Review Title: {r['title'] or '(none)'}
Product category: {r['class_name']}
Detected complaint category: {r['complaint_category']} (keywords: {', '.join(r['keywords'])})

Customer Review:
{(r['review_text'] or '')[:1500]}

Write a short, personalized, professional and empathetic apology email.
Requirements:
1. Acknowledge the customer's specific complaint.
2. Apologize sincerely and show empathy without sounding generic.
3. Suggest a realistic next step (for example a return or exchange via support).
4. Do not blame the customer. Do not make unrealistic promises.
5. Keep it between 100 and 150 words. Never mention AI or this prompt.

Return exactly this format:
Subject: <email subject>

Dear Customer,

<email body>

Best regards,
Customer Support Team"""

def env_bool(name, default="true"): return os.getenv(name, default).strip().lower() in ("1", "true", "yes", "on")
def redact(msg):
    msg = str(msg)
    for k in ("GEMINI_API_KEY", "SMTP_PASSWORD"):
        v = (os.getenv(k) or "").strip()
        for x in {v, v.replace(" ", "")}:
            if x: msg = msg.replace(x, "***")
    return msg

MODEL_CACHE = {}; GEN_ACTIVE = set(); GEN_LOCK = threading.Lock()

def pick_flash_lite(client):
    """Fastest supported Flash-Lite model available to this API key (stable, highest version)."""
    names = []
    for m in client.models.list():
        n = (getattr(m, "name", "") or "").replace("models/", ""); acts = getattr(m, "supported_actions", None) or []
        if "flash-lite" in n and (not acts or "generateContent" in acts) and not any(x in n for x in ("tts", "image", "audio", "live")): names.append(n)
    stable = [n for n in names if not any(x in n for x in ("preview", "exp"))]
    ver = lambda n: float((re.search(r"(\d+(?:\.\d+)?)", n) or [0, 0])[1])
    return sorted(stable or names, key=ver, reverse=True)[0] if names else None

def call_gemini(prompt):
    key = (os.getenv("GEMINI_API_KEY") or "").strip()
    if not key: raise HTTPException(400, "Gemini API key is missing. Set GEMINI_API_KEY in .env and restart the backend.")
    try:
        from google import genai
        from google.genai import types
    except ImportError: raise HTTPException(500, "google-genai is not installed. Run: pip install -r backend/requirements.txt")
    secs = int(os.getenv("GEMINI_TIMEOUT_SECONDS", "30"))
    try: http = types.HttpOptions(timeout=secs * 1000, retry_options=types.HttpRetryOptions(attempts=1))   # no silent multi-minute retries
    except (AttributeError, TypeError, ValueError): http = types.HttpOptions(timeout=secs * 1000)
    model = MODEL_CACHE.get("m") or os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite").strip()
    def gen(c, m):
        cfg = {"max_output_tokens": 1024, "temperature": 0.7}
        if "2.5" in m: cfg["thinking_config"] = types.ThinkingConfig(thinking_budget=0)   # no reasoning needed for a 150-word email
        return c.models.generate_content(model=m, contents=prompt, config=types.GenerateContentConfig(**cfg))
    try:
        client = genai.Client(api_key=key, http_options=http)
        try: resp = gen(client, model)
        except Exception as e:
            if not (getattr(e, "code", None) == 404 or "NOT_FOUND" in str(e)): raise
            alt = pick_flash_lite(client)       # configured model unavailable to this key -> fastest available Flash-Lite
            if not alt or alt == model: raise
            MODEL_CACHE["m"] = model = alt; resp = gen(client, alt)
        text = (resp.text or "").strip()
    except HTTPException: raise
    except Exception as e:
        m = redact(e)
        if "timed out" in m.lower() or "timeout" in m.lower(): raise HTTPException(504, f"Gemini did not respond within {secs}s (model {model}). Try again or check GEMINI_MODEL.")
        raise HTTPException(502, f"Gemini request failed (model {model}): {m[:400]}")
    if not text: raise HTTPException(502, f"Gemini returned an empty response (model {model}).")
    m = re.match(r"\s*Subject:\s*(.+?)\n+(.*)", text, re.S)
    return (m.group(1).strip(), m.group(2).strip(), model) if m else ("We're sorry about your experience", text, model)

def resp_row(r):
    d = dict(r); d["review_ref"] = f"RV-{d['review_id']:05d}"; return d
def get_resp(con, rid):
    r = con.execute("SELECT r.*,v.rating,v.title review_title,v.category complaint FROM responses r JOIN reviews v ON v.id=r.review_id WHERE r.id=?", (rid,)).fetchone()
    if not r: raise HTTPException(404, "Response not found")
    return resp_row(r)

class GenReq(BaseModel): review_id: int; response_id: Optional[int] = None

@app.post("/api/generate-response")
def generate_response(req: GenReq):
    with GEN_LOCK:
        if req.review_id in GEN_ACTIVE: raise HTTPException(409, "A response is already being generated for this review.")
        GEN_ACTIVE.add(req.review_id)
    try:
        con = db(); r = get_review(con, req.review_id)
        subject, body, model = call_gemini(prompt_for(r)); t = now()      # exactly one Gemini call per request
        if req.response_id:
            get_resp(con, req.response_id)
            con.execute("UPDATE responses SET subject=?,body=?,status='Generated',error=NULL,model=?,updated_at=?,approved_at=NULL,sent_at=NULL WHERE id=?", (subject, body, model, t, req.response_id)); rid = req.response_id
        else:
            rid = con.execute("INSERT INTO responses(review_id,subject,body,status,model,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (r["id"], subject, body, "Generated", model, t, t)).lastrowid
        con.commit(); out = get_resp(con, rid); con.close(); return out
    finally:
        with GEN_LOCK: GEN_ACTIVE.discard(req.review_id)

# ---- responses ----------------------------------------------------------------------------
class RespIn(BaseModel):
    id: Optional[int] = None; review_id: int; subject: str; body: str; recipient: Optional[str] = ""; status: Optional[str] = None

@app.post("/api/responses")
def save_response(req: RespIn):
    con = db(); get_review(con, req.review_id); t = now()
    if req.id:
        old = get_resp(con, req.id)
        st = req.status or ("Edited" if (old["subject"], old["body"]) != (req.subject, req.body) else old["status"])
        con.execute("UPDATE responses SET subject=?,body=?,recipient=?,status=?,updated_at=?,approved_at=CASE WHEN ?='Edited' THEN NULL ELSE approved_at END WHERE id=?",
                    (req.subject, req.body, req.recipient, st, t, st, req.id)); rid = req.id
    else:
        rid = con.execute("INSERT INTO responses(review_id,subject,body,recipient,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                          (req.review_id, req.subject, req.body, req.recipient, req.status or "Draft", t, t)).lastrowid
    con.commit(); out = get_resp(con, rid); con.close(); return out

@app.get("/api/responses")
def responses(q: Optional[str] = None, status: Optional[str] = None, date_from: Optional[str] = None, date_to: Optional[str] = None,
              review_id: Optional[int] = None, page: int = 1, size: int = 10):
    con = db(); w, p = ["1=1"], []
    if status: w.append("r.status=?"); p.append(status)
    if review_id: w.append("r.review_id=?"); p.append(review_id)
    if date_from: w.append("r.created_at>=?"); p.append(date_from)
    if date_to: w.append("r.created_at<=?"); p.append(date_to + "T23:59:59")
    if q: w.append("(r.body LIKE ? OR r.subject LIKE ? OR v.review_text LIKE ? OR CAST(r.review_id AS TEXT)=?)"); p += [f"%{q}%"] * 3 + [q.upper().replace("RV-", "").lstrip("0") or "0"]
    wh = " AND ".join(w); base = "FROM responses r JOIN reviews v ON v.id=r.review_id WHERE " + wh
    total = con.execute("SELECT COUNT(*) " + base, p).fetchone()[0]
    rows = con.execute("SELECT r.*,v.rating,v.title review_title,v.category complaint,v.review_text " + base + " ORDER BY r.id DESC LIMIT ? OFFSET ?", p + [size, (page - 1) * size]).fetchall()
    out = {"items": [resp_row(r) for r in rows], "total": total, "page": page, "pages": max(1, ceil(total / size))}; con.close(); return out

@app.get("/api/history")
def history(page: int = 1, size: int = 10): return responses(page=page, size=size)

@app.get("/api/responses/{rid}")
def response_detail(rid: int):
    con = db(); r = get_resp(con, rid); r["review"] = get_review(con, r["review_id"]); con.close(); return r

@app.post("/api/responses/{rid}/approve")
def approve(rid: int):
    con = db(); r = get_resp(con, rid)
    if r["status"] == "Sent": raise HTTPException(409, "Response was already sent.")
    if not (r["body"] or "").strip(): raise HTTPException(400, "Cannot approve an empty response.")
    con.execute("UPDATE responses SET status='Approved',approved_at=?,updated_at=?,error=NULL WHERE id=?", (now(), now(), rid)); con.commit()
    out = get_resp(con, rid); con.close(); return out

# ---- email --------------------------------------------------------------------------------
@app.get("/api/settings")
def settings():
    e = lambda k, d="": (os.getenv(k) or d).strip()
    checks = {k: bool(e(k)) for k in ("SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD")}
    return {"gemini_configured": bool(e("GEMINI_API_KEY")), "gemini_model": e("GEMINI_MODEL", "gemini-2.5-flash-lite"),
        "smtp_configured": all(checks.values()), "smtp_checks": checks, "smtp_host": e("SMTP_HOST"), "smtp_port": e("SMTP_PORT", "587"),
        "email_from": e("EMAIL_FROM") or e("SMTP_USER"), "test_email_mode": env_bool("TEST_EMAIL_MODE"), "test_email_to": e("TEST_EMAIL_TO"),
        "database": DB.name, "dataset": CSV.name}

class SendReq(BaseModel): response_id: int; recipient: Optional[str] = ""

@app.post("/api/send-email")
def send_email(req: SendReq):
    con = db(); r = get_resp(con, req.response_id); s = settings()
    if r["status"] == "Sent": con.close(); raise HTTPException(409, "Response was already sent.")
    if r["status"] == "Sending": con.close(); raise HTTPException(409, "This response is already being sent.")
    if r["status"] not in ("Approved", "Failed") or not r["approved_at"]: con.close(); raise HTTPException(400, "Approve the response before sending.")
    # atomic claim: a second concurrent click cannot also send
    if con.execute("UPDATE responses SET status='Sending',updated_at=? WHERE id=? AND status IN ('Approved','Failed')", (now(), r["id"])).rowcount != 1:
        con.close(); raise HTTPException(409, "This response is already being sent.")
    con.commit()
    test = s["test_email_mode"]; to = s["test_email_to"] if test else (req.recipient or r["recipient"] or "").strip()
    def fail(msg, code):
        msg = redact(msg)
        con.execute("INSERT INTO email_logs(response_id,to_addr,test_mode,success,error,created_at) VALUES(?,?,?,?,?,?)", (r["id"], to, int(test), 0, msg, now()))
        con.execute("UPDATE responses SET status='Failed',error=?,updated_at=? WHERE id=?", (msg, now(), r["id"])); con.commit(); con.close()
        raise HTTPException(code, msg)
    if not s["smtp_configured"]:
        fail("SMTP configuration incomplete - " + ", ".join(f"{k} configured: {v}" for k, v in s["smtp_checks"].items()) + ". Set them in .env and restart the backend.", 400)
    if test and not to: fail("TEST_EMAIL_MODE is true but TEST_EMAIL_TO is not configured in .env.", 400)
    if not to: fail("Recipient email is required (the dataset has no customer emails).", 400)
    host, user = s["smtp_host"], os.getenv("SMTP_USER").strip(); pw = os.getenv("SMTP_PASSWORD").strip().replace(" ", "")   # Google shows app passwords with spaces
    sender = s["email_from"] or user
    msg = EmailMessage(); msg["From"] = sender; msg["To"] = to; msg["Subject"] = ("[TEST] " if test else "") + r["subject"]
    msg.set_content((f"[Test mode - intended for: {req.recipient or r['recipient'] or r['review_ref']}]\n\n" if test else "") + r["body"])
    try:
        port = int(s["smtp_port"]); ctx = ssl.create_default_context()
        if port == 465: srv = smtplib.SMTP_SSL(host, port, timeout=20, context=ctx)
        else: srv = smtplib.SMTP(host, port, timeout=20)
        with srv:
            if port != 465: srv.ehlo(); srv.starttls(context=ctx); srv.ehlo()
            srv.login(user, pw); srv.send_message(msg)
    except smtplib.SMTPAuthenticationError as ex:
        err = ex.smtp_error.decode(errors="replace") if isinstance(ex.smtp_error, bytes) else str(ex.smtp_error)
        fail(f"Gmail rejected the login ({ex.smtp_code}): {err[:300]} - use a Google App Password (2-Step Verification required), not your normal password.", 502)
    except Exception as ex: fail(f"SMTP error connecting to {host}:{s['smtp_port']} - {type(ex).__name__}: {ex}", 502)
    t = now()
    con.execute("INSERT INTO email_logs(response_id,to_addr,test_mode,success,created_at) VALUES(?,?,?,?,?)", (r["id"], to, int(test), 1, t))
    con.execute("UPDATE responses SET status='Sent',sent_at=?,recipient=?,error=NULL,updated_at=? WHERE id=?", (t, req.recipient or r["recipient"], t, r["id"])); con.commit()
    out = get_resp(con, r["id"]); con.close()
    return {"success": True, "test_mode": test, "sent_to": to, "message": f"Email sent to {to}" + (" (test mode)." if test else "."), "response": out}
