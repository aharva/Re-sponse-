# RE:SPONSE AI

Next.js UI (original Lovable design) + FastAPI + SQLite + Gemini + SMTP, using the real clothing-reviews CSV.

## Install (from this folder)
    python -m venv .venv
    .venv\Scripts\activate          (macOS/Linux: source .venv/bin/activate)
    pip install -r backend/requirements.txt
    copy .env.example .env          (macOS/Linux: cp .env.example .env)   # then fill in .env
    cd frontend && npm install && cd ..

## Run
    python -m uvicorn backend.main:app --reload --port 8000     # terminal 1  (docs: http://localhost:8000/docs)
    cd frontend && npm run dev                                   # terminal 2  -> http://localhost:3000

First start seeds `backend/response_ai.db` from `data/reviews.csv` (~10 s). Delete the .db file to re-seed.

## .env (project root, copied from .env.example)
GEMINI_API_KEY, GEMINI_MODEL (default gemini-2.5-flash-lite; auto-falls back to the fastest available Flash-Lite), GEMINI_TIMEOUT_SECONDS, TEST_EMAIL_MODE (true = real Gmail SMTP but only to TEST_EMAIL_TO, subject prefixed [TEST]), TEST_EMAIL_TO, SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, EMAIL_FROM.
Gmail: use an App Password, host smtp.gmail.com, port 587.
Optional frontend: `frontend/.env.local` with NEXT_PUBLIC_API_URL=http://localhost:8000
