'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  AlertCircle, ArrowUpRight, BarChart3, Bell, Bot, Check, ChevronDown, ChevronRight,
  CircleHelp, ClipboardCheck, Copy, FileText, Inbox as InboxIcon, LayoutDashboard, Mail,
  MessageSquareText, Package, PanelLeft, Search, Send, Settings, Sparkles, Star, X,
} from 'lucide-react'

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

async function api(path: string, opts?: { method?: string; body?: any; timeoutMs?: number }) {
  let res: Response
  const ctl = new AbortController(); const secs = (opts?.timeoutMs ?? 30000) / 1000
  const timer = setTimeout(() => ctl.abort(), secs * 1000)
  try {
    res = await fetch(API + path, {
      method: opts?.method || 'GET',
      headers: opts?.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts?.body ? JSON.stringify(opts.body) : undefined,
      signal: ctl.signal,
    })
  } catch (e: any) {
    if (e?.name === 'AbortError') throw new Error(`The request timed out after ${secs}s. Please try again.`)
    throw new Error(`Cannot reach the backend at ${API}. Start it with: python -m uvicorn backend.main:app --port 8000`)
  }
  finally { clearTimeout(timer) }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `Request failed (${res.status})`)
  return data
}

function useLoad(path: string | null) {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(!!path)
  const [error, setError] = useState('')
  const [tick, setTick] = useState(0)
  useEffect(() => {
    if (!path) return
    let live = true
    setLoading(true); setError('')
    api(path).then(d => live && setData(d)).catch(e => live && setError(e.message)).finally(() => live && setLoading(false))
    return () => { live = false }
  }, [path, tick])
  return { data, loading, error, reload: () => setTick(t => t + 1) }
}

const fmt = (n: number) => (n ?? 0).toLocaleString()
const when = (s?: string) => (s ? new Date(s).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '—')
const tone = (s: string) => ({ Sent: 'success', Approved: 'success', Failed: 'danger', Edited: 'warning', Generated: 'neutral', Draft: 'neutral' } as any)[s] || 'neutral'

function Stars({ rating }: { rating: number }) {
  return <span className="stars" aria-label={`${rating} out of 5 stars`}>{[1, 2, 3, 4, 5].map(i => <Star key={i} size={13} fill={i <= rating ? 'currentColor' : 'none'} />)}</span>
}
function Badge({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: string }) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}
function Banner({ kind, children }: { kind: 'info' | 'error' | 'success'; children: React.ReactNode }) {
  return <div className={`banner banner-${kind}`}>{children}</div>
}
function Status({ loading, error, onRetry }: { loading: boolean; error: string; onRetry?: () => void }) {
  if (loading) return <div className="empty-state">Loading…</div>
  if (error) return <Banner kind="error">{error} {onRetry && <button className="text-button" onClick={onRetry}>Retry</button>}</Banner>
  return null
}
function Pager({ page, pages, total, set }: { page: number; pages: number; total: number; set: (p: number) => void }) {
  return <div className="pager"><span>{fmt(total)} results</span><div>
    <button className="outline-button" disabled={page <= 1} onClick={() => set(page - 1)}>Previous</button>
    <span>Page {page} of {pages}</span>
    <button className="outline-button" disabled={page >= pages} onClick={() => set(page + 1)}>Next</button></div></div>
}
function Bars({ rows, danger }: { rows: { label: string; value: number }[]; danger?: boolean }) {
  const max = Math.max(1, ...rows.map(r => r.value))
  return <div className="insight-bars">{rows.map(r => <div key={r.label}><div><span>{r.label}</span><b>{fmt(r.value)}</b></div><div className="bar-track"><div className={`bar-fill ${danger ? 'danger-fill' : ''}`} style={{ width: `${(r.value / max) * 100}%` }} /></div></div>)}</div>
}

function ReviewRow({ review: r, onClick }: { review: any; onClick: () => void }) {
  return <button className="review-row" onClick={onClick}>
    <div className="customer-avatar">{r.rating}★</div>
    <div className="review-customer"><b>{r.ref}</b><span>{r.department || 'Unknown department'} · Age {r.age ?? '—'}</span></div>
    <div className="review-product"><b>{r.class_name || 'Unknown class'}</b><span>{r.title || (r.review_text || '').slice(0, 60)}</span></div>
    <div className="review-rating"><Stars rating={r.rating} /><span>{r.rating}.0</span></div>
    <Badge tone={r.severity.toLowerCase()}>{r.severity} priority</Badge>
    <div className="review-time">{r.complaint_category}</div>
    <ChevronRight size={16} className="row-arrow" />
  </button>
}

const nav = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'inbox', label: 'Feedback inbox', icon: InboxIcon },
  { id: 'studio', label: 'Response studio', icon: MessageSquareText },
  { id: 'products', label: 'Products', icon: Package },
  { id: 'insights', label: 'Customer insights', icon: BarChart3 },
  { id: 'history', label: 'Response history', icon: ClipboardCheck },
]

function Sidebar({ active, setActive, collapsed, setCollapsed, critical, online }: any) {
  return <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
    <div className="brand"><div className="brand-mark"><span>R</span></div>{!collapsed && <div><div className="brand-name">RE:<em>SPONSE</em></div><div className="brand-sub">CUSTOMER INTELLIGENCE</div></div>}</div>
    <button className="collapse-button" aria-label="Toggle sidebar" onClick={() => setCollapsed(!collapsed)}><PanelLeft size={16} /></button>
    {!collapsed && <div className="workspace"><div className="workspace-dot">R</div><div><div className="workspace-name">Clothing Reviews</div><div className="workspace-plan">Women&apos;s E-Commerce dataset</div></div></div>}
    <div className="nav-group"><div className="nav-label">WORKSPACE</div>{nav.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${active === item.id ? 'active' : ''}`} onClick={() => setActive(item.id)}><Icon size={17} />{!collapsed && <><span>{item.label}</span>{item.id === 'inbox' && critical != null && <span className="nav-count">{fmt(critical)}</span>}</>}</button> })}</div>
    <div className="nav-group secondary"><div className="nav-label">SYSTEM</div>
      <button className={`nav-item ${active === 'settings' ? 'active' : ''}`} onClick={() => setActive('settings')}><Settings size={17} />{!collapsed && <span>Settings</span>}</button>
      <button className={`nav-item ${active === 'help' ? 'active' : ''}`} onClick={() => setActive('help')}><CircleHelp size={17} />{!collapsed && <span>Help center</span>}</button></div>
    <div className="sidebar-footer">{!collapsed && <div className="live-status"><span style={{ background: online ? undefined : 'var(--danger)' }}></span> {online ? 'API connected' : 'API offline'}</div>}</div>
  </aside>
}

function Header({ title, subtitle, onBell }: any) {
  return <header className="topbar"><div><div className="breadcrumb">RE:SPONSE AI <ChevronRight size={13} /> {title.toUpperCase()}</div><h1>{title}</h1><p>{subtitle}</p></div>
    <div className="top-actions"><button className="icon-button" aria-label="Critical reviews" title="Open critical reviews" onClick={onBell}><Bell size={18} /></button></div></header>
}

/* ---------------- Overview ---------------- */
function Overview({ go }: any) {
  const a = useLoad('/api/analytics'), k = useLoad('/api/keywords?limit=6')
  if (a.loading || a.error) return <div className="page-content"><Status {...a} onRetry={a.reload} /></div>
  const d = a.data, dist = d.rating_distribution, maxD = Math.max(...(Object.values(dist) as number[]))
  const act = d.response_activity
  return <div className="page-content"><div className="kpi-grid">
    <div className="kpi-card"><div className="kpi-head"><span>Total reviews</span><span className="kpi-icon"><FileText size={16} /></span></div><strong>{fmt(d.total_reviews)}</strong><div className="kpi-foot"><span>From the supplied dataset</span></div></div>
    <div className="kpi-card critical-card"><div className="kpi-head"><span>Critical reviews</span><span className="kpi-icon danger"><AlertCircle size={16} /></span></div><strong>{fmt(d.critical_reviews)}</strong><div className="kpi-foot danger-text"><span>{d.critical_percentage}%</span> <span>of total reviews (rating ≤ 2)</span></div></div>
    <div className="kpi-card"><div className="kpi-head"><span>Average rating</span><span className="kpi-icon star-icon"><Star size={16} /></span></div><strong>{d.average_rating} <small>/ 5</small></strong><div className="rating-line"><span style={{ width: `${d.average_rating * 20}%` }} /></div><div className="kpi-foot"><span>Across all reviews</span></div></div>
    <div className="kpi-card"><div className="kpi-head"><span>AI responses</span><span className="kpi-icon accent"><Bot size={16} /></span></div><strong>{fmt(act.total)}</strong><div className="kpi-foot positive">{fmt(act.emails_sent)} <span>sent</span></div></div>
  </div><div className="dashboard-grid">
    <div className="panel chart-panel"><div className="panel-header"><div><h2>Rating distribution</h2><p>Review volume by customer rating</p></div></div>
      <div className="bar-chart">{[1, 2, 3, 4, 5].map(r => <div className="bar-row" key={r}><span>{r}★</span><div className="bar-track"><div style={{ width: `${(dist[r] / maxD) * 100}%` }} className={`bar-fill ${r <= 2 ? 'danger-fill' : ''}`} /></div><b>{fmt(dist[r])}</b></div>)}</div>
      <div className="chart-legend"><span><i className="dot danger-dot" /> Critical <b>{fmt(d.critical_reviews)}</b></span><span><i className="dot neutral-dot" /> Non-critical <b>{fmt(d.total_reviews - d.critical_reviews)}</b></span></div></div>
    <div className="panel keyword-panel"><div className="panel-header"><div><h2>Complaint intelligence</h2><p>Most frequent words in critical reviews</p></div></div>
      <div className="keyword-list">{(k.data || []).map((x: any, i: number) => <div className="keyword-row" key={x.word}><span className="keyword-rank">0{i + 1}</span><span className="keyword-word">{x.word}</span><div className="keyword-track"><div style={{ width: `${(x.count / k.data[0].count) * 100}%` }} /></div><span className="keyword-count">{x.count}</span></div>)}</div>
      <button className="text-button" onClick={() => go('insights')}>View all insights <ArrowUpRight size={14} /></button></div></div>
    <div className="dashboard-grid" style={{ marginTop: 14 }}>
      <div className="panel recent-panel" style={{ marginTop: 0 }}><div className="panel-header"><div><h2>Recent critical reviews</h2><p>Open one to analyze and respond</p></div><button className="text-button" onClick={() => go('inbox')}>View inbox <ArrowUpRight size={14} /></button></div>
        <div className="review-table">{d.recent_critical.map((r: any) => <ReviewRow key={r.id} review={r} onClick={() => go('studio', r.id)} />)}</div></div>
      <div className="panel"><div className="panel-header"><div><h2>AI response activity</h2><p>Stored responses by status</p></div></div>
        {act.total === 0 ? <div className="empty-state">No responses generated yet.</div> : <Bars rows={Object.entries(act.by_status).map(([label, value]) => ({ label, value: value as number }))} />}
        <button className="text-button" onClick={() => go('history')}>Open response history <ArrowUpRight size={14} /></button></div></div>
  </div>
}

/* ---------------- Inbox ---------------- */
function Inbox({ go, initialCritical }: any) {
  const [f, setF] = useState<any>({ q: '', rating: '', critical: initialCritical, department: '', category: '', page: 1 })
  const [q, setQ] = useState('')
  const [open, setOpen] = useState<number | null>(null)
  useEffect(() => { const t = setTimeout(() => setF((s: any) => ({ ...s, q, page: 1 })), 300); return () => clearTimeout(t) }, [q])
  const set = (k: string, v: any) => setF((s: any) => ({ ...s, [k]: v, page: k === 'page' ? v : 1 }))
  const qs = new URLSearchParams({ page: String(f.page), size: '15', ...(f.q && { q: f.q }), ...(f.rating && { rating: f.rating }), ...(f.critical && { critical: 'true' }), ...(f.department && { department: f.department }), ...(f.category && { category: f.category }) })
  const r = useLoad('/api/reviews?' + qs)
  const d = r.data
  return <div className="page-content"><div className="inbox-toolbar">
    <div className="search-box"><Search size={16} /><input placeholder="Search review text, title, class…" value={q} onChange={e => setQ(e.target.value)} /></div>
    <select className="select-button" value={f.rating} onChange={e => set('rating', e.target.value)}><option value="">All ratings</option>{[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{n} star</option>)}</select>
    <select className="select-button" value={f.department} onChange={e => set('department', e.target.value)}><option value="">All departments</option>{(d?.departments || []).map((x: string) => <option key={x}>{x}</option>)}</select>
    <select className="select-button" value={f.category} onChange={e => set('category', e.target.value)}><option value="">All categories</option>{(d?.categories || []).map((x: string) => <option key={x}>{x}</option>)}</select></div>
    <div className="filter-tabs">{[['All reviews', false], ['Critical only (≤ 2★)', true]].map(([l, v]: any) => <button key={l} className={f.critical === v ? 'active' : ''} onClick={() => set('critical', v)}>{l}</button>)}</div>
    <div className="panel inbox-panel"><div className="inbox-header"><div><h2>Feedback inbox {d && <span>{fmt(d.total)} reviews</span>}</h2><p>Newest first · click a review for details</p></div></div>
      <Status loading={r.loading} error={r.error} onRetry={r.reload} />
      {d && !r.loading && <><div className="inbox-list">{d.items.map((x: any) => <ReviewRow key={x.id} review={x} onClick={() => setOpen(x.id)} />)}{!d.items.length && <div className="empty-state">No reviews match these filters.</div>}</div>
        <Pager page={d.page} pages={d.pages} total={d.total} set={p => set('page', p)} /></>}</div>
    {open != null && <ReviewDrawer id={open} close={() => setOpen(null)} go={go} />}</div>
}

function ReviewDrawer({ id, close, go }: any) {
  const r = useLoad(`/api/reviews/${id}`)
  const [busy, setBusy] = useState(''); const [msg, setMsg] = useState<any>(null)
  const lock = useRef(false)
  const gen = async () => {
    if (lock.current) return
    lock.current = true; setMsg(null); setBusy('Analyzing review...')
    try {
      await api('/api/analyze-review', { method: 'POST', body: { review_id: id } })
      setBusy('Generating...')
      const resp = await api('/api/generate-response', { method: 'POST', body: { review_id: id }, timeoutMs: 60000 })
      setMsg({ kind: 'success', text: 'Response generated successfully.' }); setBusy('')
      go('studio', id, resp.id)
    } catch (e: any) { setMsg({ kind: 'error', text: e.message }); setBusy('') } finally { lock.current = false }
  }
  const d = r.data
  return <div className="drawer-bg" onClick={close}><aside className="drawer" onClick={e => e.stopPropagation()}>
    <div className="panel-header"><div><span className="eyebrow">REVIEW DETAILS</span><h2>{d ? d.ref : 'Loading…'}</h2></div><button className="icon-button" aria-label="Close" onClick={close}><X size={18} /></button></div>
    <Status loading={r.loading} error={r.error} onRetry={r.reload} />
    {d && <>
      <div className="rating-value" style={{ margin: '14px 0' }}><Stars rating={d.rating} /><b>{d.rating}.0</b>{d.is_critical ? <Badge tone="danger">Critical review</Badge> : null}</div>
      <div className="original-review"><h4>{d.title || 'Untitled review'}</h4><p>{d.review_text || 'No review text.'}</p></div>
      <div className="kv">{[['Department', d.department], ['Division', d.division], ['Class', d.class_name], ['Recommended', d.recommended ? 'Yes' : 'No'], ['Positive feedback', d.positive_feedback], ['Age', d.age], ['Clothing ID', d.clothing_id]].map(([k, v]) => <div key={k as string}><span>{k}</span><b>{v ?? '—'}</b></div>)}</div>
      <div className="analysis"><div className="review-label"><span>AI analysis</span></div>
        <div className="analysis-grid"><div><span>Severity</span><Badge tone={d.severity.toLowerCase()}>{d.severity}</Badge></div><div><span>Complaint category</span><b>{d.complaint_category}</b></div></div>
        <div className="detected"><span>Complaint keywords</span><div>{d.keywords.map((k: string) => <Badge key={k}>{k}</Badge>)}</div></div></div>
      {busy && <Banner kind="info">{busy}</Banner>}{msg && <Banner kind={msg.kind}>{msg.text}</Banner>}
      <button className="primary-button full" disabled={!!busy} onClick={gen}><Sparkles size={15} /> Generate AI Response</button></>}
  </aside></div>
}

/* ---------------- Studio ---------------- */
function Studio({ reviewId, responseId, go }: any) {
  const rev = useLoad(reviewId ? `/api/reviews/${reviewId}` : null)
  const st = useLoad('/api/settings')
  const [resp, setResp] = useState<any>(null)
  const [subject, setSubject] = useState(''); const [body, setBody] = useState(''); const [to, setTo] = useState('')
  const [editing, setEditing] = useState(false); const [busy, setBusy] = useState(''); const [msg, setMsg] = useState<any>(null)
  const [analysis, setAnalysis] = useState<any>(null)
  const load = (r: any) => { setResp(r); setSubject(r?.subject || ''); setBody(r?.body || ''); setTo(r?.recipient || ''); setEditing(false) }
  useEffect(() => {
    setMsg(null); load(null); setAnalysis(null)
    if (!reviewId) return
    const p = responseId ? api(`/api/responses/${responseId}`) : api(`/api/responses?review_id=${reviewId}&size=1`).then(x => x.items[0] || null)
    p.then(load).catch(e => setMsg({ kind: 'error', text: e.message }))
  }, [reviewId, responseId])

  const lock = useRef(false)
  const run = async (label: string, ok: string, fn: () => Promise<any>) => {
    if (lock.current) return
    lock.current = true; setMsg(null); setBusy(label)
    try { const out = await fn(); if (ok) setMsg({ kind: 'success', text: ok }); return out }
    catch (e: any) { setMsg({ kind: 'error', text: e.message }) } finally { setBusy(''); lock.current = false }
  }
  const dirty = !!resp && (subject !== resp.subject || body !== resp.body || to !== (resp.recipient || ''))
  const save = async () => { const r = await api('/api/responses', { method: 'POST', body: { id: resp?.id, review_id: reviewId, subject, body, recipient: to } }); load(r); return r }
  const analyze = () => run('Analyzing review...', 'Analysis saved.', async () => setAnalysis(await api('/api/analyze-review', { method: 'POST', body: { review_id: reviewId } })))
  const generate = () => run('Generating...', 'Response generated successfully.', async () => load(await api('/api/generate-response', { method: 'POST', body: { review_id: reviewId, response_id: resp?.id }, timeoutMs: 60000 })))
  const saveEdit = () => run('Saving edit...', 'Edit saved. Approve the response to enable sending.', save)
  const approve = () => run('Approving...', 'Response approved.', async () => { const r = dirty ? await save() : resp; load(await api(`/api/responses/${r.id}/approve`, { method: 'POST' })) })
  const send = () => run('Sending email...', '', async () => {
    const out = await api('/api/send-email', { method: 'POST', body: { response_id: resp.id, recipient: to }, timeoutMs: 60000 }); load(out.response); setMsg({ kind: 'success', text: out.message })
  }).finally(() => api(`/api/responses/${resp?.id}`).then(load).catch(() => {}))

  if (!reviewId) return <div className="page-content"><div className="panel placeholder-panel"><div className="generate-card"><div className="generate-icon"><Bot size={22} /></div><h3>No review selected</h3><p>Pick a critical review from the Feedback inbox to analyze it and draft a response.</p><button className="primary-button" onClick={() => go('inbox')}>Open Feedback inbox</button></div></div></div>
  const r = rev.data
  if (rev.loading || rev.error) return <div className="page-content"><Status {...rev} onRetry={rev.reload} /></div>
  const sa = analysis || { severity: r.severity, category: r.complaint_category, keywords: r.keywords }
  const canApprove = resp && ['Generated', 'Edited', 'Draft', 'Failed'].includes(resp.status)
  const canSend = resp && (resp.status === 'Approved' || (resp.status === 'Failed' && resp.approved_at)) && !dirty
  const test = st.data?.test_email_mode
  return <div className="page-content studio-page"><div className="studio-toolbar"><div><span className="eyebrow">CASE {r.ref}</span><h2>Response studio</h2><p>Review the analysis, refine the response, approve, then send.</p></div>
    <Badge tone={resp ? tone(resp.status) : 'neutral'}>{resp ? `Status: ${resp.status}` : 'No response yet'}</Badge></div>
    <div className="studio-grid"><section className="panel case-panel">
      <div className="panel-header"><div><h3>Customer review</h3><p>{r.department} · {r.class_name} · Clothing #{r.clothing_id}</p></div></div>
      <div className="case-meta"><div><span>Rating</span><div className="rating-value"><Stars rating={r.rating} /><b>{r.rating}.0</b></div></div><div><span>Recommended</span><b>{r.recommended ? 'Yes' : 'No'}</b></div></div>
      <div className="original-review"><div className="review-label"><span>Original review</span>{r.is_critical ? <Badge tone="danger">Critical review</Badge> : null}</div><h4>{r.title || 'Untitled review'}</h4><p>{r.review_text}</p></div>
      <div className="analysis"><div className="review-label"><span>AI analysis</span><span className="analysis-live"><span /> Computed from review</span></div>
        <div className="analysis-grid"><div><span>Severity</span><Badge tone={sa.severity.toLowerCase()}>{sa.severity}</Badge></div><div><span>Category</span><b>{sa.category}</b></div><div><span>Positive votes</span><b>{r.positive_feedback}</b></div></div>
        <div className="detected"><span>Complaint keywords</span><div>{sa.keywords.map((k: string) => <Badge key={k}>{k}</Badge>)}</div></div></div>
      <button className="outline-button full" disabled={!!busy} onClick={analyze}><Sparkles size={15} /> Analyze review</button></section>
      <section className="panel response-panel"><div className="panel-header"><div><h3>Generated response</h3><p>Gemini draft · human review required</p></div><div className="ai-orb"><Sparkles size={15} /></div></div>
        {busy && <Banner kind="info">{busy}</Banner>}{msg && <Banner kind={msg.kind}>{msg.text}</Banner>}
        {resp?.status === 'Failed' && resp.error && <Banner kind="error">Last send failed: {resp.error}</Banner>}
        {!resp ? <div className="generate-card"><div className="generate-icon"><Bot size={22} /></div><h3>Ready to draft a response</h3><p>Gemini will write an empathetic email that acknowledges this specific complaint and suggests a realistic next step.</p><button className="primary-button" disabled={!!busy} onClick={generate}><Sparkles size={15} /> Generate Response</button></div> : <>
          <div className="field"><label htmlFor="subject">Subject</label><input id="subject" value={subject} readOnly={!editing} onChange={e => setSubject(e.target.value)} /></div>
          <div className="field"><label htmlFor="recipient">Recipient email {test && <span>Test mode: delivered to the test address</span>}</label><input id="recipient" type="email" placeholder={test ? 'Optional in test mode' : 'customer@example.com'} value={to} onChange={e => setTo(e.target.value)} /></div>
          <div className="field body-field"><label htmlFor="body">Email body <span>{editing ? 'Editing' : 'Read-only until Edit is pressed'}</span></label><textarea id="body" value={body} readOnly={!editing} onChange={e => setBody(e.target.value)} />
            <div className="editor-foot"><span>{body.trim().split(/\s+/).filter(Boolean).length} words{resp.model ? ` · ${resp.model}` : ''}</span><button className="copy-button" onClick={() => navigator.clipboard?.writeText(`Subject: ${subject}\n\n${body}`)}><Copy size={13} /> Copy</button></div></div>
          <div className="response-actions">
            <button className="outline-button" disabled={!!busy} onClick={generate}>Regenerate</button>
            {editing ? <button className="outline-button" disabled={!!busy} onClick={saveEdit}><Check size={15} /> Save edit</button> : <button className="outline-button" disabled={!!busy || resp.status === 'Sent'} onClick={() => setEditing(true)}>Edit</button>}
            <button className="outline-button" disabled={!!busy || !canApprove} onClick={approve}><Check size={15} /> Approve</button>
            <button className="primary-button" disabled={!!busy || !canSend} onClick={send}><Send size={15} /> {resp.status === 'Sent' ? 'Sent' : 'Send Email'}</button></div>
          {dirty && <small className="hint">Unsaved changes — Save edit or Approve to store them before sending.</small>}</>}
      </section></div></div>
}

/* ---------------- Products ---------------- */
function Products() {
  const p = useLoad('/api/products')
  return <div className="page-content"><div className="panel placeholder-panel"><div className="panel-header"><div><h2>Product classes</h2><p>Real classes from the dataset, with review statistics</p></div></div>
    <Status loading={p.loading} error={p.error} onRetry={p.reload} />
    {p.data && <div className="product-grid">{p.data.classes.map((c: any, i: number) => <div className="product-card" key={c.name} style={{ gridTemplateColumns: '46px 1.5fr 90px 90px 90px' }}>
      <div className={`product-art art-${i % 4}`}><Package size={26} /></div><div><h3>{c.name}</h3><p>{c.department} · {fmt(c.reviews)} reviews</p></div>
      <div className="product-stat"><b>{c.avg_rating}</b><span>avg. rating</span></div><div className="product-stat"><b className="danger-text">{c.critical_rate}%</b><span>critical rate</span></div><div className="product-stat"><b>{c.recommend_rate}%</b><span>recommend</span></div></div>)}</div>}</div>
    {p.data && <div className="panel" style={{ marginTop: 14 }}><div className="panel-header"><div><h2>Most problematic items</h2><p>Clothing IDs with the highest critical rate (min. 20 reviews)</p></div></div>
      <table className="tbl"><thead><tr><th>Clothing ID</th><th>Class</th><th>Reviews</th><th>Critical</th><th>Avg rating</th></tr></thead><tbody>{p.data.most_problematic_items.map((x: any) => <tr key={x.clothing_id}><td>#{x.clothing_id}</td><td>{x.class_name}</td><td>{x.reviews}</td><td className="danger-text">{x.critical}</td><td>{x.avg_rating}</td></tr>)}</tbody></table></div>}</div>
}

/* ---------------- Customer insights (analytics only) ---------------- */
function Insights() {
  const a = useLoad('/api/analytics'), k = useLoad('/api/keywords?limit=12')
  if (a.loading || a.error) return <div className="page-content"><Status {...a} onRetry={a.reload} /></div>
  const d = a.data, dist = d.rating_distribution
  const tbl = (rows: any[]) => <table className="tbl"><thead><tr><th>Name</th><th>Reviews</th><th>Critical</th><th>Critical %</th><th>Avg rating</th></tr></thead><tbody>{rows.slice(0, 6).map(x => <tr key={x.name}><td>{x.name}</td><td>{fmt(x.reviews)}</td><td>{fmt(x.critical)}</td><td className="danger-text">{x.critical_rate}%</td><td>{x.avg_rating}</td></tr>)}</tbody></table>
  return <div className="page-content"><div className="kpi-grid">
    <div className="kpi-card"><div className="kpi-head"><span>Recommendation rate</span></div><strong>{d.recommendation_rate}%</strong><div className="kpi-foot"><span>of customers recommend</span></div></div>
    <div className="kpi-card"><div className="kpi-head"><span>Average rating</span></div><strong>{d.average_rating} <small>/ 5</small></strong><div className="rating-line"><span style={{ width: `${d.average_rating * 20}%` }} /></div></div>
    <div className="kpi-card critical-card"><div className="kpi-head"><span>Critical review %</span></div><strong>{d.critical_percentage}%</strong><div className="kpi-foot danger-text">{fmt(d.critical_reviews)} <span>critical reviews</span></div></div>
    <div className="kpi-card"><div className="kpi-head"><span>Critical breakdown</span></div><strong>{fmt(d.critical_by_rating['1'])} <small>1★</small> · {fmt(d.critical_by_rating['2'])} <small>2★</small></strong></div></div>
    <div className="dashboard-grid">
      <div className="panel"><div className="panel-header"><div><h2>Rating distribution</h2></div></div><Bars rows={[1, 2, 3, 4, 5].map(r => ({ label: `${r}★`, value: dist[r] }))} /></div>
      <div className="panel"><div className="panel-header"><div><h2>Top complaint keywords</h2><p>Critical reviews only</p></div></div><Bars danger rows={(k.data || []).map((x: any) => ({ label: x.word, value: x.count }))} /></div></div>
    <div className="dashboard-grid">
      <div className="panel"><div className="panel-header"><div><h2>Complaint categories</h2><p>Most common issues in critical reviews</p></div></div><Bars danger rows={d.complaint_categories.map((c: any) => ({ label: c.name, value: c.count }))} /></div>
      <div className="panel"><div className="panel-header"><div><h2>Most problematic departments</h2></div></div>{tbl(d.problem_departments)}</div></div>
    <div className="panel" style={{ marginTop: 14 }}><div className="panel-header"><div><h2>Most problematic classes</h2><p>Ranked by critical rate (min. 50 reviews)</p></div></div>{tbl(d.problem_classes)}</div></div>
}

/* ---------------- Response history (audit trail) ---------------- */
function History({ go }: any) {
  const [f, setF] = useState<any>({ q: '', status: '', date_from: '', date_to: '', page: 1 })
  const [open, setOpen] = useState<any>(null); const [msg, setMsg] = useState<any>(null); const [busy, setBusy] = useState('')
  const set = (k: string, v: any) => setF((s: any) => ({ ...s, [k]: v, page: k === 'page' ? v : 1 }))
  const qs = new URLSearchParams({ page: String(f.page), size: '10', ...Object.fromEntries(Object.entries(f).filter(([k, v]) => v && k !== 'page')) as any })
  const h = useLoad('/api/responses?' + qs)
  const lock = useRef(false)
  const act = async (label: string, fn: () => Promise<any>) => {
    if (lock.current) return
    lock.current = true; setMsg(null); setBusy(label)
    try { const m = await fn(); setMsg({ kind: 'success', text: m }) } catch (e: any) { setMsg({ kind: 'error', text: e.message }) }
    setBusy(''); lock.current = false; h.reload(); if (open) api(`/api/responses/${open.id}`).then(setOpen).catch(() => {})
  }
  const approve = (r: any) => act('Approving...', async () => { await api(`/api/responses/${r.id}/approve`, { method: 'POST' }); return `${r.review_ref} approved.` })
  const send = (r: any, to?: string) => act('Sending email...', async () => (await api('/api/send-email', { method: 'POST', body: { response_id: r.id, recipient: to ?? r.recipient ?? '' }, timeoutMs: 60000 })).message)
  const canA = (r: any) => ['Draft', 'Generated', 'Edited', 'Failed'].includes(r.status)
  const canS = (r: any) => r.status === 'Approved' || (r.status === 'Failed' && r.approved_at)
  const d = h.data
  return <div className="page-content"><div className="inbox-toolbar">
    <div className="search-box"><Search size={16} /><input placeholder="Search review ID or response text…" value={f.q} onChange={e => set('q', e.target.value)} /></div>
    <select className="select-button" value={f.status} onChange={e => set('status', e.target.value)}><option value="">All statuses</option>{['Draft', 'Generated', 'Edited', 'Approved', 'Sent', 'Failed'].map(s => <option key={s}>{s}</option>)}</select>
    <input type="date" className="select-button" value={f.date_from} onChange={e => set('date_from', e.target.value)} aria-label="From date" />
    <input type="date" className="select-button" value={f.date_to} onChange={e => set('date_to', e.target.value)} aria-label="To date" /></div>
    {busy && <Banner kind="info">{busy}</Banner>}{msg && <Banner kind={msg.kind}>{msg.text}</Banner>}
    <div className="panel"><Status loading={h.loading} error={h.error} onRetry={h.reload} />
      {d && !h.loading && (d.items.length === 0 ? <div className="empty-state">No responses yet. Generate one from the Feedback inbox.</div> : <div style={{ overflowX: 'auto' }}><table className="tbl"><thead><tr><th>Review</th><th>Rating</th><th>Complaint</th><th>Response</th><th>Status</th><th>Created</th><th>Approved</th><th>Sent</th><th>Actions</th></tr></thead><tbody>
        {d.items.map((r: any) => <tr key={r.id}><td><b>{r.review_ref}</b></td><td>{r.rating}★</td><td>{r.complaint}</td><td className="clip">{r.subject}</td><td><Badge tone={tone(r.status)}>{r.status}</Badge></td><td>{when(r.created_at)}</td><td>{when(r.approved_at)}</td><td>{when(r.sent_at)}</td>
          <td className="row-actions"><button className="outline-button" onClick={() => setOpen(r)}>View</button><button className="outline-button" disabled={r.status === 'Sent'} onClick={() => go('studio', r.review_id, r.id)}>Edit</button><button className="outline-button" disabled={!canA(r) || !!busy} onClick={() => approve(r)}>Approve</button><button className="outline-button" disabled={!canS(r) || !!busy} onClick={() => setOpen(r)}>Send</button></td></tr>)}</tbody></table></div>)}
      {d && <Pager page={d.page} pages={d.pages} total={d.total} set={p => set('page', p)} />}</div>
    {open && <HistoryModal r={open} close={() => setOpen(null)} send={send} canS={canS(open)} busy={!!busy} />}</div>
}
function HistoryModal({ r, close, send, canS, busy }: any) {
  const [to, setTo] = useState(r.recipient || '')
  return <div className="drawer-bg" onClick={close}><aside className="drawer" onClick={e => e.stopPropagation()}>
    <div className="panel-header"><div><span className="eyebrow">{r.review_ref} · {r.status.toUpperCase()}</span><h2>{r.subject}</h2></div><button className="icon-button" aria-label="Close" onClick={close}><X size={18} /></button></div>
    <div className="original-review"><div className="review-label"><span>Original review · {r.rating}★</span></div><p>{r.review_text || ''}</p></div>
    <div className="original-review"><div className="review-label"><span>Generated response</span></div><p style={{ whiteSpace: 'pre-wrap' }}>{r.body}</p></div>
    <div className="kv"><div><span>Created</span><b>{when(r.created_at)}</b></div><div><span>Approved</span><b>{when(r.approved_at)}</b></div><div><span>Sent</span><b>{when(r.sent_at)}</b></div></div>
    {r.error && <Banner kind="error">{r.error}</Banner>}
    {canS && <><div className="field"><label htmlFor="hto">Recipient email</label><input id="hto" type="email" placeholder="Optional in test mode" value={to} onChange={e => setTo(e.target.value)} /></div>
      <button className="primary-button full" style={{ marginTop: 14 }} disabled={busy} onClick={() => send(r, to)}><Send size={15} /> Send email</button></>}
  </aside></div>
}

/* ---------------- Settings / Help ---------------- */
function SettingsPage() {
  const s = useLoad('/api/settings'); const d = s.data
  const row = (k: string, v: any, ok?: boolean) => <div className="kv-row"><span>{k}</span><b>{ok === undefined ? (v || '—') : <Badge tone={ok ? 'success' : 'danger'}>{ok ? 'Configured' : 'Missing'}</Badge>}</b></div>
  return <div className="page-content"><Status loading={s.loading} error={s.error} onRetry={s.reload} />{d && <>
    <Banner kind="info">Secrets live in the <code>.env</code> file next to <code>backend/</code> and are never sent to the browser. Edit it and restart the backend to change anything here.</Banner>
    <div className="dashboard-grid"><div className="panel"><div className="panel-header"><div><h2>Gemini API</h2></div><Bot size={18} /></div>{row('API key (GEMINI_API_KEY)', '', d.gemini_configured)}{row('Model (GEMINI_MODEL)', d.gemini_model)}</div>
      <div className="panel"><div className="panel-header"><div><h2>Email (SMTP)</h2></div><Mail size={18} /></div>{row('SMTP credentials', '', d.smtp_configured)}{Object.entries(d.smtp_checks || {}).map(([k, v]) => row(`${k} configured`, String(v)))}{row('Host / port', `${d.smtp_host || '—'}:${d.smtp_port}`)}{row('From address', d.email_from)}</div></div>
    <div className="dashboard-grid" style={{ marginTop: 14 }}><div className="panel"><div className="panel-header"><div><h2>Test email mode</h2></div></div>{row('TEST_EMAIL_MODE', '', d.test_email_mode)}{row('Delivered to (TEST_EMAIL_TO)', d.test_email_to)}<p className="muted">{d.test_email_mode ? 'Safe: emails are only ever sent to the test address, never to customers.' : 'LIVE: emails go to the recipient entered on each response.'}</p></div>
      <div className="panel"><div className="panel-header"><div><h2>Application</h2></div></div>{row('Database', d.database)}{row('Dataset', d.dataset)}{row('API URL', API)}</div></div></>}</div>
}
function Help({ go }: any) {
  const steps = [['Feedback inbox', 'inbox', 'Search/filter real reviews and open one to see its analysis.'], ['Generate AI response', 'inbox', 'Analysis is stored, then Gemini drafts the email on the backend.'], ['Response studio', 'studio', 'Edit the draft, approve it, then send.'], ['Response history', 'history', 'Audit trail of every response and its status.'], ['Settings', 'settings', 'See which keys are configured and whether test email mode is on.']]
  return <div className="page-content"><div className="panel"><div className="panel-header"><div><h2>How RE:SPONSE AI works</h2><p>Review → analysis → Gemini draft → human edit → approve → send → history</p></div></div>
    {steps.map(([t, to, d]) => <div className="kv-row" key={t}><span><b>{t}</b><br />{d}</span><button className="text-button" onClick={() => go(to)}>Open <ArrowUpRight size={14} /></button></div>)}
    <p className="muted">Statuses: Draft → Generated → Edited → Approved → Sent (or Failed). Critical reviews are ratings of 1–2 stars. Missing keys always produce a clear configuration error.</p></div></div>
}

/* ---------------- App ---------------- */
const titles: any = {
  overview: ['Customer intelligence overview', 'Real statistics from the review dataset.'],
  inbox: ['Feedback inbox', 'Search, filter and open every customer review.'],
  studio: ['Response studio', 'Review the analysis, refine the response, and send when ready.'],
  products: ['Product intelligence', 'Review statistics by product class.'],
  insights: ['Customer insights', 'Analytics on sentiment, complaints and problem areas.'],
  history: ['Response history', 'Audit trail of generated, approved and sent responses.'],
  settings: ['Settings', 'Gemini, email and application configuration.'],
  help: ['Help center', 'How the workflow fits together.'],
}

export default function Page() {
  const [active, setActive] = useState('overview'); const [collapsed, setCollapsed] = useState(false)
  const [reviewId, setReviewId] = useState<number | null>(null); const [responseId, setResponseId] = useState<number | null>(null)
  const [critInbox, setCritInbox] = useState(false)
  const [crit, setCrit] = useState<number | null>(null); const [online, setOnline] = useState(true)
  useEffect(() => { api('/api/analytics').then(d => { setCrit(d.critical_reviews); setOnline(true) }).catch(() => setOnline(false)) }, [])
  const go = useCallback((page: string, rid?: number, respId?: number) => {
    if (page === 'studio') { setReviewId(rid ?? reviewId); setResponseId(respId ?? null) }
    setActive(page)
  }, [reviewId])
  const bell = () => { setCritInbox(true); setActive('inbox') }
  const content = active === 'overview' ? <Overview go={go} /> : active === 'inbox' ? <Inbox key={String(critInbox)} go={go} initialCritical={critInbox} />
    : active === 'studio' ? <Studio reviewId={reviewId} responseId={responseId} go={go} /> : active === 'products' ? <Products />
    : active === 'insights' ? <Insights /> : active === 'history' ? <History go={go} /> : active === 'settings' ? <SettingsPage /> : <Help go={go} />
  return <div className="app-shell"><Sidebar active={active} setActive={(p: string) => { if (p === 'inbox') setCritInbox(false); setActive(p) }} collapsed={collapsed} setCollapsed={setCollapsed} critical={crit} online={online} />
    <main className="main"><Header title={titles[active][0]} subtitle={titles[active][1]} onBell={bell} />{content}</main></div>
}
